//
//  TableViewCellTypeC.h
//  2-23多类型cell
//
//  Created by wyman on 2017/2/23.
//  Copyright © 2017年 wyman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SectionCellProtocol.h"

@interface TableViewCellTypeC : UITableViewCell <SectionCellProtocol>

@end
