//
//  ModelTypeC.h
//  2-23多类型cell
//
//  Created by wyman on 2017/2/23.
//  Copyright © 2017年 wyman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SectionModelProtocol.h"

@interface ModelTypeC : NSObject <SectionModelProtocol>

@end
