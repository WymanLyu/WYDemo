//
//  AlphaViewController.h
//  WYCustomNavigationBar
//
//  Created by wyman on 2017/2/6.
//  Copyright © 2017年 wyman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlphaViewController : UIViewController

@end
