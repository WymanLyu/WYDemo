//
//  YSDefaultImp.h
//  YouSay
//
//  Created by wyman on 2016/12/12.
//  Copyright © 2016年 tykj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YSProtocolExtension.h"

@protocol YSDefaultImp <NSObject>

- (void)call;

@end

