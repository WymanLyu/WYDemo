//
//  YSDefaultImp.m
//  YouSay
//
//  Created by wyman on 2016/12/12.
//  Copyright © 2016年 tykj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YSDefaultImp.h"


defaultImplementation(YSDefaultImp)

- (void)call {
    NSLog(@"一个可以默认实现的协议哟~~~");
}

+ (void)ss {
    
}

@end
