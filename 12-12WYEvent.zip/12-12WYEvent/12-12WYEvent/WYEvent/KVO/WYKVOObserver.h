//
//  WYKVOObserver.h
//  12-12WYEvent
//
//  Created by wyman on 2017/3/25.
//  Copyright © 2017年 tykj. All rights reserved.
//

// 这个对象解决的是KVO在，监听者挂掉后要移除的问题

#import <Foundation/Foundation.h>

@interface WYKVOObserver : NSObject

@end
