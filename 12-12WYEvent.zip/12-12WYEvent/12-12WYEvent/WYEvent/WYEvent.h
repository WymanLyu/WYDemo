//
//  WYEvent.h
//  12-12WYEvent
//
//  Created by wyman on 2017/2/10.
//  Copyright © 2017年 tykj. All rights reserved.
//

#ifndef WYEvent_h
#define WYEvent_h

#import "NSObject+WYEvent"

#endif /* WYEvent_h */
