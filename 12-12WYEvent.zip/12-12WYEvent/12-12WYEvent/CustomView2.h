//
//  CustomView2.h
//  12-12WYEvent
//
//  Created by wyman on 2017/2/10.
//  Copyright © 2017年 tykj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomView2 : UIView

@property (nonatomic, weak) UIViewController *vc;

@end
