//
//  ViewController.h
//  4-18校验不信任SSL
//
//  Created by wyman on 2017/4/18.
//  Copyright © 2017年 wyman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

